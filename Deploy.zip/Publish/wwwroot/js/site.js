﻿// Write your JavaScript code.
$(window).on("load",
    function () {
        $("#infoModal").modal("show");
    });